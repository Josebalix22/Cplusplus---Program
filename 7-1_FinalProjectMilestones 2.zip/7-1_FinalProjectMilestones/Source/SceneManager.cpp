#include "SceneManager.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/transform.hpp>
#include <iostream>
#include "camera.h"
#include <unistd.h> // For getcwd
#include <string>
#include <filesystem> // For std::filesystem::current_path

// Declaration of global variables and defines
namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  Constructor for the SceneManager class.
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();
    m_loadedTextures = 0;
    m_camera = nullptr; // Camera will be set externally
    m_isPerspective = true; // Start in perspective mode
    std::cout << "SceneManager constructed, m_pShaderManager: " << m_pShaderManager << std::endl;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  Destructor for the SceneManager class.
 ***********************************************************/
SceneManager::~SceneManager()
{
    m_pShaderManager = nullptr;
    delete m_basicMeshes;
    m_basicMeshes = nullptr;
    // Do not delete m_camera
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  Loads textures from image files, configures OpenGL texture
 *  parameters, generates mipmaps, and stores in texture slots.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
    int width = 0;
    int height = 0;
    int colorChannels = 0;
    GLuint textureID = 0;

    // Flip images vertically when loaded
    stbi_set_flip_vertically_on_load(true);

    // Construct full path to texture
     std::string exePath = std::filesystem::current_path();
     std::string fullPath = "Utilities/textures/" + std::string(filename);
     std::string vertexPath = "vertexShader.glsl";
     std::string fragmentPath = "fragmentShader.glsl";
     std::cout << "📸 Attempting to load: " << fullPath << std::endl;

    unsigned char* image = stbi_load(
        fullPath.c_str(),
        &width,
        &height,
        &colorChannels,
        0);

    if (image)
    {
        std::cout << "Successfully loaded image: " << filename << ", width: " << width << ", height: " << height << ", channels: " << colorChannels << std::endl;

        glGenTextures(1, &textureID);
        glBindTexture(GL_TEXTURE_2D, textureID);

        // Set texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // Set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        // Load image data based on color channels
        if (colorChannels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (colorChannels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
            stbi_image_free(image);
            return false;
        }

        // Generate mipmaps for texture
        glGenerateMipmap(GL_TEXTURE_2D);
        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0);

        // Register texture with tag
        m_textureIDs[m_loadedTextures].ID = textureID;
        m_textureIDs[m_loadedTextures].tag = tag;
        m_loadedTextures++;

        return true;
    }

    std::cout << "Could not load image: " << filename << std::endl;
    return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  Binds loaded OpenGL textures to memory slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  Frees loaded OpenGL textures from memory.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glDeleteTextures(1, &m_textureIDs[i].ID);
    }
}

/***********************************************************
 *  FindTextureID()
 *
 *  Finds a loaded texture by tag and returns its ID.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        if (m_textureIDs[i].tag == tag)
            return m_textureIDs[i].ID;
    }
    return -1;
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  Finds the slot of a loaded texture by tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        if (m_textureIDs[i].tag == tag)
            return i;
    }
    return -1;
}

/***********************************************************
 *  FindMaterial()
 *
 *  Finds a defined material by tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
    for (const auto& mat : m_objectMaterials)
    {
        if (mat.tag == tag)
        {
            material = mat;
            return true;
        }
    }
    return false;
}

/***********************************************************
 *  SetTransformations()
 *
 *  Sets the transformation matrix for the next draw command.
 ***********************************************************/
void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ)
{
    glm::mat4 modelView = glm::translate(positionXYZ) *
        glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f)) *
        glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f)) *
        glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f)) *
        glm::scale(scaleXYZ);
    if (m_pShaderManager)
        m_pShaderManager->setMat4Value(g_ModelName, modelView);
}

/***********************************************************
 *  SetShaderColor()
 *
 *  Sets the color for the next draw command, disabling texture.
 ***********************************************************/
void SceneManager::SetShaderColor(
    float redColorValue,
    float greenColorValue,
    float blueColorValue,
    float alphaValue)
{
    glm::vec4 currentColor(redColorValue, greenColorValue, blueColorValue, alphaValue);
    if (m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
    }
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  Sets the texture for the next draw command.
 ***********************************************************/
void SceneManager::SetShaderTexture(std::string textureTag)
{
    if (m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, true);
        int textureSlot = FindTextureSlot(textureTag);
        m_pShaderManager->setSampler2DValue(g_TextureValueName, textureSlot);
    }
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  Sets the UV scale for texture mapping.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
    if (m_pShaderManager)
        m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  Sets the material properties for the next draw command.
 ***********************************************************/
void SceneManager::SetShaderMaterial(std::string materialTag)
{
    OBJECT_MATERIAL material;
    if (FindMaterial(materialTag, material) && m_pShaderManager)
    {
        m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
        m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
        m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
        m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
        m_pShaderManager->setFloatValue("material.shininess", material.shininess);
    }
}

/***********************************************************
 *  UpdateCameraMatrices()
 *
 *  Updates view and projection matrices in the shader.
 ***********************************************************/
void SceneManager::UpdateCameraMatrices(float aspectRatio)
{
    if (m_pShaderManager && m_camera)
    {
        glm::mat4 view = m_camera->GetViewMatrix();
        glm::mat4 projection;
        if (m_isPerspective)
        {
            projection = m_camera->GetProjectionMatrix(aspectRatio);
        }
        else
        {
            float orthoSize = 5.0f;
            projection = glm::ortho(
                -orthoSize * aspectRatio, orthoSize * aspectRatio,
                -orthoSize, orthoSize,
                0.1f, 100.0f);
            view = glm::lookAt(
                glm::vec3(0.0f, 10.0f, 2.0f),
                glm::vec3(0.0f, 1.0f, 2.0f),
                glm::vec3(0.0f, 0.0f, -1.0f));
        }
        m_pShaderManager->setMat4Value("view", view);
        m_pShaderManager->setMat4Value("projection", projection);
    }
    else
    {
        std::cout << "UpdateCameraMatrices: m_pShaderManager or m_camera is null" << std::endl;
    }
}

/***********************************************************
 *  ProcessMouseMovement()
 *
 *  Processes mouse movement to update camera orientation.
 ***********************************************************/
void SceneManager::ProcessMouseMovement(float xoffset, float yoffset)
{
    if (m_camera)
    {
        m_camera->ProcessMouseMovement(xoffset, yoffset);
        UpdateCameraMatrices(800.0f / 600.0f);
    }
}

/***********************************************************
 *  ProcessMouseScroll()
 *
 *  Processes mouse scroll to adjust camera movement speed.
 ***********************************************************/
void SceneManager::ProcessMouseScroll(float yoffset)
{
    if (m_camera)
    {
        m_camera->ProcessMouseScroll(yoffset);
        UpdateCameraMatrices(800.0f / 600.0f);
    }
}

/***********************************************************
 *  ToggleProjectionMode()
 *
 *  Toggles between perspective and orthographic projection.
 ***********************************************************/
void SceneManager::ToggleProjectionMode()
{
    m_isPerspective = !m_isPerspective;
    std::cout << "Toggled to " << (m_isPerspective ? "perspective" : "orthographic") << " projection" << std::endl;
    UpdateCameraMatrices(800.0f / 600.0f);
}

/***********************************************************
 *  ProcessKeyboardInput()
 *
 *  Processes keyboard input for camera movement.
 ***********************************************************/
void SceneManager::ProcessKeyboardInput(GLFWwindow* window, float deltaTime)
{
    if (m_camera)
    {
        if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
            m_camera->ProcessKeyboard(FORWARD, deltaTime);
        if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
            m_camera->ProcessKeyboard(BACKWARD, deltaTime);
        if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
            m_camera->ProcessKeyboard(LEFT, deltaTime);
        if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
            m_camera->ProcessKeyboard(RIGHT, deltaTime);
        if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
            m_camera->ProcessKeyboard(UP, deltaTime);
        if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
            m_camera->ProcessKeyboard(DOWN, deltaTime);
    }
    else
    {
        std::cout << "ProcessKeyboardInput: m_camera is null" << std::endl;
    }
}

/***********************************************************
 *  IsPerspectiveMode()
 *
 *  Checks the current projection mode.
 ***********************************************************/
bool SceneManager::IsPerspectiveMode() const
{
    return m_isPerspective;
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  Configures material settings for objects in the 3D scene
 *  using the Phong lighting model for realistic lighting.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
    // Plane material with high shininess for reflective surface
    OBJECT_MATERIAL planeMaterial;
    planeMaterial.tag = "plane_material";
    planeMaterial.ambientColor = glm::vec3(0.2f, 0.02f, 0.02f); // Subtle red ambient
    planeMaterial.ambientStrength = 0.3f;
    planeMaterial.diffuseColor = glm::vec3(0.8f, 0.1f, 0.1f); // Red diffuse to match stripe
    planeMaterial.specularColor = glm::vec3(0.8f, 0.8f, 0.8f); // Strong white specular for reflection
    planeMaterial.shininess = 64.0f; // High shininess for glossy look
    m_objectMaterials.push_back(planeMaterial);

    // Vase body material with ceramic texture
    OBJECT_MATERIAL vaseBodyMaterial;
    vaseBodyMaterial.tag = "vase_body";
    vaseBodyMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f); // Neutral ambient
    vaseBodyMaterial.ambientStrength = 0.2f;
    vaseBodyMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f); // Grayish diffuse
    vaseBodyMaterial.specularColor = glm::vec3(0.3f, 0.3f, 0.3f); // Subtle specular
    vaseBodyMaterial.shininess = 16.0f; // Moderate shininess
    m_objectMaterials.push_back(vaseBodyMaterial);

    // Vase rim material with black ceramic texture
    OBJECT_MATERIAL vaseRimMaterial;
    vaseRimMaterial.tag = "vase_rim";
    vaseRimMaterial.ambientColor = glm::vec3(0.1f, 0.1f, 0.1f); // Dark ambient
    vaseRimMaterial.ambientStrength = 0.2f;
    vaseRimMaterial.diffuseColor = glm::vec3(0.4f, 0.4f, 0.4f); // Dark gray diffuse
    vaseRimMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f); // Subtle specular
    vaseRimMaterial.shininess = 16.0f; // Moderate shininess
    m_objectMaterials.push_back(vaseRimMaterial);

    // Dirt material with soil texture
    OBJECT_MATERIAL dirtMaterial;
    dirtMaterial.tag = "vase_dirt";
    dirtMaterial.ambientColor = glm::vec3(0.1f, 0.05f, 0.05f); // Earthy ambient
    dirtMaterial.ambientStrength = 0.2f;
    dirtMaterial.diffuseColor = glm::vec3(0.25f, 0.15f, 0.1f); // Brown diffuse
    dirtMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f); // Minimal specular
    dirtMaterial.shininess = 8.0f; // Low shininess for matte look
    m_objectMaterials.push_back(dirtMaterial);

    // Red stripe material (no texture, matches plane color)
    OBJECT_MATERIAL redStripeMaterial;
    redStripeMaterial.tag = "red_stripe";
    redStripeMaterial.ambientColor = glm::vec3(0.2f, 0.02f, 0.02f); // Subtle red ambient
    redStripeMaterial.ambientStrength = 0.3f;
    redStripeMaterial.diffuseColor = glm::vec3(0.8f, 0.1f, 0.1f); // Red diffuse
    redStripeMaterial.specularColor = glm::vec3(0.5f, 0.5f, 0.5f); // Moderate specular
    redStripeMaterial.shininess = 32.0f; // Glossy look
    m_objectMaterials.push_back(redStripeMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  Configures light sources for the 3D scene using the Phong
 *  lighting model to ensure all objects are clearly lit.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
    // Enable Phong lighting in the shader
    m_pShaderManager->setBoolValue(g_UseLightingName, true);

    // Primary point light near vase for strong illumination
    m_pShaderManager->setVec3Value("lightSources[0].position", 0.0f, 1.0f, 2.0f); // At vase center
    m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.2f, 0.18f, 0.15f); // Warm ambient
    m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 1.0f, 0.95f, 0.9f); // Warm white diffuse
    m_pShaderManager->setVec3Value("lightSources[0].specularColor", 1.0f, 0.95f, 0.9f); // Warm specular
    m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 8.0f); // Strong focus
    m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.8f); // Strong highlights

    // Secondary ambient light to prevent complete shadows
    m_pShaderManager->setVec3Value("lightSources[1].position", 0.0f, 5.0f, 0.0f); // Overhead
    m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.15f, 0.15f, 0.15f); // Soft neutral ambient
    m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.3f, 0.3f, 0.3f); // Soft diffuse
    m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.2f, 0.2f, 0.2f); // Minimal specular
    m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 4.0f); // Broad spread
    m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.2f); // Subtle highlights

    // Tertiary light: soft glow between stem and leaves
    m_pShaderManager->setVec3Value("lightSources[2].position", 0.0f, 3.8f, 0.0f); // Between leaf tips
    m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 5.0f); // Wider reach
    m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.1f, 0.2f, 0.1f); // Gentle green ambient
    m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 0.3f, 0.6f, 0.3f); // Soft green diffuse
    m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.4f, 0.8f, 0.4f); // Slight shimmer
    m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 2.0f); // Localized focus
    m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.3f); // Gentle highlight

}

/***********************************************************
 *  PrepareScene()
 *
 *  Prepares the 3D scene by loading meshes and textures.
 ***********************************************************/
void SceneManager::PrepareScene()
{
    // Load meshes for the scene
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadTaperedCylinderMesh();
    m_basicMeshes->LoadConeMesh();

    // Load textures for objects
    CreateGLTexture("ceramic_tile_diffuse_resized.jpg", "vase_body");
    CreateGLTexture("ceramic_black_diffuse.jpg", "vase_rim");
    CreateGLTexture("soil_dirt_diffuse_converted.jpg", "vase_dirt");
    CreateGLTexture("marble_floor_diffuse_resized.jpg", "ground");

    // Bind all textures to slots
    BindGLTextures();

    // Define materials for Phong lighting
    DefineObjectMaterials();

    // Configure light sources
    SetupSceneLights();
}

/***********************************************************
 *  RenderScene()
 *
 *  Renders the 3D scene by transforming and drawing shapes
 *  with textures and materials for Phong lighting.
 ***********************************************************/
void SceneManager::RenderScene()
{
    // Update camera matrices
    UpdateCameraMatrices(800.0f / 600.0f);

    // Transformation variables
    glm::vec3 scaleXYZ;
    float XrotationDegrees = 0.0f;
    float YrotationDegrees = 0.0f;
    float ZrotationDegrees = 0.0f;
    glm::vec3 positionXYZ;
   // Update camera matrices

    // Ground Plane (Marble Texture)
    scaleXYZ = glm::vec3(10.0f, 0.01f, 10.0f);
    positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderMaterial("ground"); // Matches texture tag
    SetShaderTexture("ground");
    SetTextureUVScale(2.0f, 2.0f);
    if (IsPerspectiveMode())
        m_basicMeshes->DrawPlaneMesh();

    // Vase Base Body (Ceramic Tile Texture)
    scaleXYZ = glm::vec3(1.5f, 1.5f, 1.5f);
    positionXYZ = glm::vec3(0.0f, 0.75f, 2.0f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderMaterial("vase_body");
    SetShaderTexture("vase_body");
    SetTextureUVScale(1.0f, 1.0f);
    m_basicMeshes->DrawTaperedCylinderMesh();

    // Dirt Inside Vase (Soil Texture)
    scaleXYZ = glm::vec3(1.4f, 0.05f, 1.4f);
    positionXYZ = glm::vec3(0.0f, 1.45f, 2.0f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderMaterial("vase_dirt");
    SetShaderTexture("vase_dirt");
    SetTextureUVScale(1.0f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    // Red Stripe (No Texture, Colored Material)
    scaleXYZ = glm::vec3(1.55f, 0.05f, 1.55f);
    positionXYZ = glm::vec3(0.0f, 0.75f, 2.0f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(0.8f, 0.1f, 0.1f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    // Stem (No Texture)
    scaleXYZ = glm::vec3(0.2f, 2.5f, 0.2f);
    positionXYZ = glm::vec3(0.0f, 2.25f, 0.0f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(0.1f, 0.4f, 0.2f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    // Leaf 1
    scaleXYZ = glm::vec3(0.3f, 1.5f, 0.3f);
    positionXYZ = glm::vec3(-0.4f, 3.6f, 0.0f);
    SetTransformations(scaleXYZ, -40.0f, -30.0f, 0.0f, positionXYZ);
    SetShaderColor(0.0f, 0.5f, 0.2f, 1.0f);
    m_basicMeshes->DrawConeMesh();

    // Leaf 2
    positionXYZ = glm::vec3(0.4f, 3.8f, 0.2f);
    SetTransformations(scaleXYZ, -45.0f, 30.0f, 5.0f, positionXYZ);
    SetShaderColor(0.0f, 0.5f, 0.2f, 1.0f);
    m_basicMeshes->DrawConeMesh();

    // Leaf 3
    positionXYZ = glm::vec3(0.0f, 4.0f, -0.3f);
    SetTransformations(scaleXYZ, -25.0f, 5.0f, -10.0f, positionXYZ);
    SetShaderColor(0.0f, 0.5f, 0.2f, 1.0f);
    m_basicMeshes->DrawConeMesh();
   
}

/***********************************************************
 *  SetCamera()
 *
 *  Sets the camera for the scene.
 ***********************************************************/
void SceneManager::SetCamera(Camera* camera)
{
    m_camera = camera;
}