#include <iostream>         // error handling and output
#include <cstdlib>          // EXIT_FAILURE

#include <GL/glew.h>        // GLEW library
#include "GLFW/glfw3.h"     // GLFW library

// GLM Math Header inclusions
#include <glm/glm.hpp>
#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "SceneManager.h"
#include "ViewManager.h"
#include "ShapeMeshes.h"
#include "ShaderManager.h"

// Namespace for declaring global variables
namespace
{
	const char* const WINDOW_TITLE = "7-1 FinalProject and Milestones"; // Macro for window title

	GLFWwindow* g_Window = nullptr; // Main GLFW window

	SceneManager* g_SceneManager = nullptr;   // scene manager object for managing the 3D scene prepare and render
	ShaderManager* g_ShaderManager = nullptr; // shader manager object for dynamic interaction with the shader code
	ViewManager* g_ViewManager = nullptr;     // view manager object for managing the 3D view setup and projection to 2D
}

// Function declarations - all functions that are called manually
// need to be pre-declared at the beginning of the source code.
bool InitializeGLFW();
bool InitializeGLEW();

/***********************************************************
 *  main(int, char*)
 *
 *  This function gets called after the application has been
 *  launched.
 ***********************************************************/
int main(int argc, char* argv[])
{
	// if GLFW fails initialization, then terminate the application
	if (InitializeGLFW() == false)
	{
		return(EXIT_FAILURE);
	}

	// try to create a new shader manager object
	g_ShaderManager = new ShaderManager();

	// try to create a new view manager object
	g_ViewManager = new ViewManager(g_ShaderManager);

	// try to create the main display window
	g_Window = g_ViewManager->CreateDisplayWindow(WINDOW_TITLE);
	glfwSetInputMode(g_Window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);


	// if GLEW fails initialization, then terminate the application
	if (InitializeGLEW() == false)
	{
		return(EXIT_FAILURE);
	}

	// load the shader code from the external GLSL files
	g_ShaderManager->LoadShaders(
		"../../Utilities/shaders/vertexShader.glsl",
		"../../Utilities/shaders/fragmentShader.glsl");
	g_ShaderManager->use();

	// try to create a new scene manager object
	g_SceneManager = new SceneManager(g_ShaderManager);

	// create and assign the main camera
	Camera* cameraPtr = new Camera(glm::vec3(0.0f, 2.0f, 10.0f));  // or any other valid position
	g_SceneManager->SetCamera(cameraPtr);

	// prepare the 3D scene
	g_SceneManager->PrepareScene();

	// main render loop will keep running until the application is closed 
	while (!glfwWindowShouldClose(g_Window))
	{
		// calculate delta time
		static float lastFrame = 0.0f;
		float currentFrame = glfwGetTime();
		float deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;

		// handle camera movement
		g_SceneManager->ProcessKeyboardInput(g_Window, deltaTime);

		// enable z-depth
		glEnable(GL_DEPTH_TEST);

		// clear the frame and z buffers
		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// update view/projection matrices
		g_ViewManager->PrepareSceneView();

		// render the 3D scene
		g_SceneManager->RenderScene();

		// swap the back buffer with the front buffer
		glfwSwapBuffers(g_Window);

		// process window events
		glfwPollEvents();
	}

	// clear the allocated manager objects from memory
	if (g_SceneManager != nullptr)
	{
		delete g_SceneManager;
		g_SceneManager = nullptr;
	}
	if (g_ViewManager != nullptr)
	{
		delete g_ViewManager;
		g_ViewManager = nullptr;
	}
	if (g_ShaderManager != nullptr)
	{
		delete g_ShaderManager;
		g_ShaderManager = nullptr;
	}
	if (cameraPtr != nullptr)
	{
		delete cameraPtr;
		cameraPtr = nullptr;
	}

	// terminates the program successfully
	exit(EXIT_SUCCESS);
}

/***********************************************************
 *	InitializeGLFW()
 * 
 *  This function is used to initialize the GLFW library.   
 ***********************************************************/
bool InitializeGLFW()
{
	glfwInit();

#ifdef __APPLE__
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#else
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 6);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#endif

	return(true);
}

/***********************************************************
 *	InitializeGLEW()
 *
 *  This function is used to initialize the GLEW library.
 ***********************************************************/
bool InitializeGLEW()
{
	GLenum GLEWInitResult = glewInit();
	if (GLEW_OK != GLEWInitResult)
	{
		std::cerr << glewGetErrorString(GLEWInitResult) << std::endl;
		return false;
	}

	std::cout << "INFO: OpenGL Successfully Initialized\n";
	
	std::cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << "\n" << std::endl;
	return true;
}
